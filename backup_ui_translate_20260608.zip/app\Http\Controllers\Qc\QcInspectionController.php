<?php

namespace App\Http\Controllers\Qc;

use App\Http\Controllers\Controller;
use App\Models\PrItem;
use App\Models\PurchaseOrder;
use App\Models\QcInspection;
use App\Models\QcItem;
use App\Models\User;
use App\Notifications\SystemNotification;
use App\Support\StatusHelper;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Yajra\DataTables\Facades\DataTables;

class QcInspectionController extends Controller
{
    private const ACTUAL_FIELD_BY_DIMENSION = [
        'thickness' => 'actual_thickness',
        'd_inner' => 'actual_d_inner',
        'd_outer' => 'actual_d_outer',
        'width' => 'actual_width',
        'length' => 'actual_length',
        'weight' => 'actual_weight',
    ];

    /**
     * Tampilkan daftar inspeksi (Menunggu vs Riwayat)
     */
    public function index()
    {
        $waitingCount = PurchaseOrder::where('status', 'waiting_qc')->count();
        $historyCount = QcInspection::count();

        return view('qc.inspections.index', compact('waitingCount', 'historyCount'));
    }

    public function dataWaiting(Request $request)
    {
        $query = PurchaseOrder::with([
            'supplier',
            'quotations' => fn($query) => $query->withCount('items'),
        ])
            ->where('status', 'waiting_qc')
            ->orderBy('actual_arrival', 'asc');

        return DataTables::eloquent($query)
            ->addColumn('po_number_display', fn($po) => $po->po_number)
            ->addColumn('supplier_name', fn($po) => $po->supplier->name ?? '-')
            ->addColumn('arrival_date', fn($po) => $po->actual_arrival ? $po->actual_arrival->format('d M Y') : '-')
            ->addColumn('item_count', fn($po) => $po->quotations->sum('items_count') . ' Item')
            ->addColumn('action', fn($po) => '<a href="' . route('qc.inspections.create', $po->id) . '" class="btn btn-sm btn-primary" style="background-color: var(--adasi-blue);"><i class="bi bi-clipboard-check me-1"></i> Mulai Inspeksi</a>')
            ->rawColumns(['action'])
            ->make(true);
    }

    public function dataHistory(Request $request)
    {
        $query = QcInspection::with(['purchaseOrder.supplier', 'inspector'])
            ->orderBy('inspected_at', 'desc');

        if ($request->filled('status') && in_array($request->status, ['ok', 'ng'], true)) {
            $query->where('status', $request->status);
        }

        return DataTables::eloquent($query)
            ->addColumn('po_number', fn($i) => $i->purchaseOrder->po_number ?? '-')
            ->addColumn('supplier_name', fn($i) => $i->purchaseOrder->supplier->name ?? '-')
            ->addColumn('inspected_date', fn($i) => $i->inspected_at?->format('d M Y, H:i') ?? '-')
            ->addColumn('status_badge', fn($i) => StatusHelper::badge(
                StatusHelper::qcBadge($i->status),
                StatusHelper::qcLabel($i->status)
            ))
            ->addColumn('inspector_name', fn($i) => $i->inspector->name ?? '-')
            ->addColumn('action', fn($i) => '<a href="' . route('qc.inspections.show', $i->id) . '" class="btn btn-sm btn-outline-info"><i class="bi bi-eye"></i> Detail</a>')
            ->rawColumns(['status_badge', 'action'])
            ->make(true);
    }

    /**
     * Form mulai inspeksi
     */
    public function create($po_id)
    {
        $po = PurchaseOrder::with(['supplier', 'quotations.items.prItem'])->findOrFail($po_id);

        if ($po->status !== 'waiting_qc') {
            return redirect()->route('qc.inspections.index')->with('error', 'PO ini tidak dalam status Menunggu QC.');
        }

        // Cek apakah sudah pernah diinspeksi
        if (QcInspection::where('po_id', $po->id)->exists()) {
            return redirect()->route('qc.inspections.index')->with('error', 'PO ini sudah pernah diinspeksi.');
        }

        return view('qc.inspections.create', compact('po'));
    }

    /**
     * Simpan hasil inspeksi
     */
    public function store(Request $request, $po_id)
    {
        $po = PurchaseOrder::with(['quotations.items.prItem'])->findOrFail($po_id);
        $poPrItems = $po->quotations
            ->flatMap(fn($quotation) => $quotation->items->pluck('prItem'))
            ->filter()
            ->keyBy('id');

        $this->prepareInspectionInput($request, $poPrItems);

        $rules = [
            'items' => 'required|array',
            'items.*.pr_item_id' => ['required', Rule::in($poPrItems->keys()->all())],
            'items.*.actual_thickness' => 'nullable|numeric',
            'items.*.actual_d_inner' => 'nullable|numeric',
            'items.*.actual_d_outer' => 'nullable|numeric',
            'items.*.actual_width' => 'nullable|numeric',
            'items.*.actual_length' => 'nullable|numeric',
            'items.*.actual_weight' => 'nullable|numeric',
            'items.*.status' => 'required|in:ok,ng',
            'items.*.notes' => 'nullable|string',
            'attachments' => 'nullable|array',
            'attachments.*' => 'nullable|array',
            'attachments.*.*' => 'nullable|file|mimes:jpg,jpeg,png|max:10240',
        ];

        foreach ($request->input('items', []) as $index => $itemData) {
            if (($itemData['status'] ?? null) === 'ng') {
                $rules["attachments.{$index}"] = 'required|array|min:1';
                $rules["attachments.{$index}.*"] = 'required|file|mimes:jpg,jpeg,png|max:10240';
            }
        }

        $validated = $request->validate($rules, [
            'items.*.pr_item_id.in' => 'Material inspeksi tidak sesuai dengan PO ini.',
            'attachments.*.required' => 'Foto bukti wajib diunggah untuk setiap item berstatus NG.',
            'attachments.*.min' => 'Foto bukti wajib diunggah untuk setiap item berstatus NG.',
            'attachments.*.*.required' => 'Foto bukti wajib diunggah untuk setiap item berstatus NG.',
            'attachments.*.*.mimes' => 'Foto bukti NG harus berupa file JPG, JPEG, atau PNG.',
            'attachments.*.*.max' => 'Ukuran foto bukti NG maksimal 10MB per file.',
        ]);

        try {
            DB::beginTransaction();

            $po = PurchaseOrder::whereKey($po_id)
                ->lockForUpdate()
                ->firstOrFail();
            $po->load(['supplier', 'quotations.items.prItem']);

            if ($po->status !== 'waiting_qc') {
                throw new \RuntimeException('PO ini tidak valid untuk diinspeksi.');
            }

            if (QcInspection::where('po_id', $po->id)->exists()) {
                throw new \RuntimeException('PO ini sudah pernah diinspeksi.');
            }

            // Cek status keseluruhan
            $overallStatus = 'ok';
            foreach ($validated['items'] as $itemData) {
                if ($itemData['status'] === 'ng') {
                    $overallStatus = 'ng';
                    break;
                }
            }

            // Buat Inspeksi
            $inspection = QcInspection::create([
                'po_id' => $po->id,
                'inspected_by' => auth()->id(),
                'status' => $overallStatus,
                'inspected_at' => now(),
            ]);

            $uploadedFiles = $request->file('attachments', []);

            // Simpan QC Items
            foreach ($validated['items'] as $index => $itemData) {
                $measurements = $this->sanitizeActualMeasurements(
                    $itemData,
                    $poPrItems->get((int) $itemData['pr_item_id'])
                );

                $qcItem = QcItem::create($measurements + [
                    'inspection_id' => $inspection->id,
                    'pr_item_id' => $itemData['pr_item_id'],
                    'status' => $itemData['status'],
                    'notes' => $itemData['notes'] ?? null,
                ]);

                if (($itemData['status'] ?? null) === 'ng') {
                    foreach ($uploadedFiles[$index] ?? [] as $file) {
                        if (! $file instanceof UploadedFile || ! $file->isValid()) {
                            continue;
                        }

                        $this->saveAttachment($file, $inspection);
                    }
                }
            }

            if ($overallStatus === 'ng' && ! $inspection->attachments()->exists()) {
                throw new \RuntimeException('Foto bukti NG tidak terkirim. Silakan unggah ulang foto bukti sebelum menyimpan inspeksi.');
            }

            // Update PO Status & Kirim Notifikasi
            $purchasingUsers = User::where('role', 'purchasing')->get();

            if ($overallStatus === 'ok') {
                $po->update(['status' => 'completed']);
                foreach ($purchasingUsers as $pUser) {
                    /** @var User $pUser */
                    $pUser->notify(new SystemNotification(
                        'Inspeksi QC Selesai',
                        'Material dari ' . $po->po_number . ' telah lulus inspeksi QC',
                        route('purchasing.purchase-orders.show', $po->id),
                        'bi-check-circle text-success'
                    ));
                }
            } else {
                $po->update(['status' => 'claim_needed']);
                foreach ($purchasingUsers as $pUser) {
                    /** @var User $pUser */
                    $pUser->notify(new SystemNotification(
                        'Material NG Ditemukan',
                        'Material dari ' . $po->po_number . ' dinyatakan NG oleh QC. Silakan ajukan klaim ke supplier.',
                        route('purchasing.claims.create', $inspection->id),
                        'bi-exclamation-triangle text-danger'
                    ));
                }
            }

            DB::commit();

            return redirect()->route('qc.inspections.show', $inspection->id)->with('success', 'Hasil inspeksi berhasil disimpan.');

        } catch (\RuntimeException $e) {
            DB::rollBack();
            return back()->withInput()->with('error', $e->getMessage());
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('QC Inspection store failed', [
                'po_id' => $po_id,
                'user_id' => auth()->id(),
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Terjadi kesalahan saat menyimpan inspeksi. Silakan coba lagi.');
        }
    }

    private function prepareInspectionInput(Request $request, $poPrItems): void
    {
        $items = $request->input('items');

        if (! is_array($items)) {
            return;
        }

        $prepared = [];
        foreach ($items as $index => $itemData) {
            if (! is_array($itemData)) {
                continue;
            }

            $prItem = $poPrItems->get((int) ($itemData['pr_item_id'] ?? 0));
            $prepared[$index] = array_merge(
                $itemData,
                $this->sanitizeActualMeasurements($itemData, $prItem)
            );
        }

        $request->merge(['items' => $prepared]);
    }

    private function sanitizeActualMeasurements(array $itemData, ?PrItem $prItem): array
    {
        $relevantDimensions = $prItem
            ? PrItem::relevantDimensionFields($prItem->shape)
            : [];
        $relevantDimensions[] = 'weight';

        $measurements = [];
        foreach (self::ACTUAL_FIELD_BY_DIMENSION as $dimension => $field) {
            $measurements[$field] = in_array($dimension, $relevantDimensions, true)
                ? ($itemData[$field] ?? null)
                : null;
        }

        return $measurements;
    }

    /**
     * Tampilkan detail inspeksi
     */
    public function show($id)
    {
        $inspection = QcInspection::with([
            'purchaseOrder.supplier',
            'inspector',
            'items.prItem',
            'attachments'
        ])->findOrFail($id);

        return view('qc.inspections.show', compact('inspection'));
    }

    /**
     * Tambah foto bukti untuk inspeksi NG yang sudah tersimpan.
     */
    public function storeAttachments(Request $request, $id)
    {
        $inspection = QcInspection::findOrFail($id);

        if ($inspection->status !== 'ng') {
            return back()->with('error', 'Foto bukti hanya dapat ditambahkan untuk inspeksi berstatus NG.');
        }

        $request->validate([
            'attachments' => 'required|array|min:1',
            'attachments.*' => 'required|file|mimes:jpg,jpeg,png|max:10240',
        ], [
            'attachments.required' => 'Pilih minimal 1 foto bukti NG.',
            'attachments.min' => 'Pilih minimal 1 foto bukti NG.',
            'attachments.*.mimes' => 'Foto bukti NG harus berupa file JPG, JPEG, atau PNG.',
            'attachments.*.max' => 'Ukuran foto bukti NG maksimal 10MB per file.',
        ]);

        foreach ($request->file('attachments', []) as $file) {
            if (! $file instanceof UploadedFile || ! $file->isValid()) {
                continue;
            }

            $this->saveAttachment($file, $inspection);
        }

        return back()->with('success', 'Foto bukti QC berhasil ditambahkan.');
    }

    private function saveAttachment(UploadedFile $file, Model $attachable): void
    {
        $path = 'attachments/' . now()->format('Y/m') . '/' . $file->hashName();
        $stream = fopen($file->getPathname(), 'r');

        if (! $stream) {
            throw new \RuntimeException('File tidak dapat dibaca. Silakan unggah ulang file.');
        }

        try {
            Storage::disk('private')->put($path, $stream);
        } finally {
            fclose($stream);
        }

        $attachable->attachments()->create([
            'file_path' => $path,
            'file_name' => $file->getClientOriginalName(),
            'file_type' => $file->getMimeType(),
            'uploaded_by' => auth()->id(),
        ]);
    }
}

(function (window, document) {
    'use strict';

    const selector = '[data-async-export]';
    const activeExports = new Map();
    const trackedExportJobs = new Map();
    const pollIntervalMs = 1000;
    const pollTimeoutMs = 660000;
    const maxConsecutivePollFailures = 5;
    const completedExportRetentionMs = 30000;
    const pendingExportStorageKey = 'adasi:pending-export-jobs:v1';
    const downloadClaimStoragePrefix = 'adasi:export-download-claim:';
    const progressStageLabels = Object.freeze({
        queued: 'Waiting for processing',
        preparing: 'Preparing data',
        generating: 'Generating workbook',
        finalizing: 'Finalizing file',
        completed: 'Completed',
        failed: 'Failed',
    });
    let confirmationOpen = false;

    document.documentElement.dataset.asyncExportReady = 'true';

    const isAsyncExportUrl = (url) => {
        try {
            const target = new URL(url, window.location.origin);
            const path = target.pathname.replace(/\/+$/, '');

            return target.origin === window.location.origin && (
                /^\/(purchasing|supplier|qc)\/export\//.test(path)
                || path === '/supplier/price-history/export'
            );
        } catch (error) {
            return false;
        }
    };

    const isAsyncExportControl = (control) => control.matches(selector)
        || isAsyncExportUrl(control instanceof HTMLFormElement ? control.action : control.href);

    const notify = (type, title, text) => {
        if (window.AdasiToast) {
            window.AdasiToast.show({ type, title, message: text });
            return;
        }

        window.__adasiToastQueue = window.__adasiToastQueue || [];
        window.__adasiToastQueue.push({ type, title, message: text });
    };

    const exportActions = (exportsUrl) => exportsUrl ? [{
        label: 'View jobs',
        variant: 'primary',
        url: exportsUrl,
    }] : [];

    const createStartingToast = () => {
        if (!window.AdasiToast) return null;

        return window.AdasiToast.progress({
            title: 'Starting export',
            message: 'Submitting the export request...',
            progressLabel: 'Starting',
        });
    };

    const normalizeExportJobId = (value) => value === null || value === undefined
        ? ''
        : String(value);

    const readPendingExports = () => {
        try {
            const records = JSON.parse(window.localStorage.getItem(pendingExportStorageKey) || '[]');

            return Array.isArray(records)
                ? records.filter((record) => record
                    && normalizeExportJobId(record.exportJobId)
                    && typeof record.statusUrl === 'string'
                    && new URL(record.statusUrl, window.location.origin).origin === window.location.origin)
                : [];
        } catch (error) {
            return [];
        }
    };

    const writePendingExports = (records) => {
        try {
            window.localStorage.setItem(pendingExportStorageKey, JSON.stringify(records.slice(-25)));
        } catch (error) {
            // The current-page polling path remains available when storage is disabled.
        }
    };

    const persistPendingExport = (state) => {
        if (!state.exportJobId || !state.statusUrl) return;

        const records = readPendingExports().filter((record) => (
            normalizeExportJobId(record.exportJobId) !== normalizeExportJobId(state.exportJobId)
        ));

        records.push({
            exportJobId: normalizeExportJobId(state.exportJobId),
            statusUrl: state.statusUrl,
            startedAt: state.startedAt,
            status: state.lastStatus,
            stage: state.lastStage,
            progress: state.lastProgress,
            processedRows: state.lastProcessedRows,
            totalRows: state.lastTotalRows,
            message: state.lastMessage,
        });
        writePendingExports(records);
    };

    const removePersistedExport = (exportJobId) => {
        const normalizedId = normalizeExportJobId(exportJobId);
        if (!normalizedId) return;

        writePendingExports(readPendingExports().filter((record) => (
            normalizeExportJobId(record.exportJobId) !== normalizedId
        )));
    };

    const downloadClaimKey = (exportJobId) => (
        `${downloadClaimStoragePrefix}${normalizeExportJobId(exportJobId)}`
    );

    const claimDownload = (exportJobId) => {
        const key = downloadClaimKey(exportJobId);
        if (key.endsWith(':')) return false;

        try {
            const current = JSON.parse(window.localStorage.getItem(key) || 'null');
            if (current && Number(current.claimedAt) > Date.now() - 10 * 60 * 1000) {
                return false;
            }

            window.localStorage.setItem(key, JSON.stringify({ claimedAt: Date.now() }));
            return true;
        } catch (error) {
            return true;
        }
    };

    const releaseDownloadClaim = (exportJobId) => {
        try {
            window.localStorage.removeItem(downloadClaimKey(exportJobId));
        } catch (error) {
            // Ignore storage cleanup failures.
        }
    };

    const removeExpiredTrackedJobs = () => {
        const now = Date.now();

        trackedExportJobs.forEach((expiresAt, exportJobId) => {
            if (expiresAt !== Infinity && expiresAt <= now) {
                trackedExportJobs.delete(exportJobId);
            }
        });
    };

    const trackExportJob = (exportJobId) => {
        const normalizedId = normalizeExportJobId(exportJobId);
        if (normalizedId) trackedExportJobs.set(normalizedId, Infinity);
    };

    const releaseTrackedExportJob = (exportJobId, retainBriefly = false) => {
        const normalizedId = normalizeExportJobId(exportJobId);
        if (!normalizedId) return;

        if (retainBriefly) {
            trackedExportJobs.set(normalizedId, Date.now() + completedExportRetentionMs);
            return;
        }

        trackedExportJobs.delete(normalizedId);
    };

    const isTrackingNotification = (notification = {}) => {
        if (!['export.completed', 'export.failed'].includes(notification.event)) {
            return false;
        }

        removeExpiredTrackedJobs();

        const exportJobId = normalizeExportJobId(notification.export_job_id);
        return exportJobId !== '' && trackedExportJobs.has(exportJobId);
    };

    const updateExportToast = (state, changes) => {
        if (!state.toastId && state.rehydrateToast && window.AdasiToast) {
            state.toastId = window.AdasiToast.progress({
                title: changes.title || 'Export in progress',
                message: changes.message || 'The export is continuing in the background.',
                progress: changes.progress,
                indeterminate: changes.indeterminate === true,
                progressLabel: changes.progressLabel || 'Processing',
            });
            state.rehydrateToast = false;
        }

        if (state.toastId && window.AdasiToast?.update(state.toastId, changes)) return;
        if (state.silent && !changes.forceNotify) return;
        notify(changes.type || 'info', changes.title || 'Export update', changes.message || '');
    };

    const findActiveExport = (exportJobId) => {
        const normalizedId = normalizeExportJobId(exportJobId);
        if (!normalizedId) return null;

        return Array.from(activeExports.values())
            .find((state) => normalizeExportJobId(state.exportJobId) === normalizedId) || null;
    };

    const applyProgressUpdate = (state, payload = {}) => {
        if (!state || !['queued', 'processing', 'completed', 'failed'].includes(payload.status)) {
            return;
        }

        const stage = typeof payload.stage === 'string' && progressStageLabels[payload.stage]
            ? payload.stage
            : payload.status;
        const numericProgress = payload.progress === null || payload.progress === undefined
            ? null
            : Number(payload.progress);
        const progress = Number.isFinite(numericProgress)
            ? Math.min(100, Math.max(0, Math.round(numericProgress)))
            : null;
        const processedRows = Math.max(0, Number(payload.processed_rows) || 0);
        const totalRows = Math.max(0, Number(payload.total_rows) || 0);
        const signature = [
            payload.status,
            stage,
            progress,
            processedRows,
            totalRows,
            payload.message || '',
        ].join(':');

        if (state.lastProgressSignature === signature
            && !(state.rehydrateToast && window.AdasiToast)) {
            return;
        }

        state.lastStatus = payload.status;
        state.lastStage = stage;
        state.lastProgress = progress;
        state.lastProcessedRows = processedRows;
        state.lastTotalRows = totalRows;
        state.lastMessage = payload.message || '';
        state.lastProgressSignature = signature;

        persistPendingExport(state);

        const changes = {
            title: payload.status === 'completed'
                ? 'Export completed'
                : payload.status === 'failed'
                    ? 'Export could not be completed'
                    : payload.status === 'queued' ? 'Export queued' : 'Export in progress',
            message: payload.message || 'The export is continuing in the background.',
            progressLabel: totalRows > 0 && ['generating', 'finalizing'].includes(stage)
                ? `${processedRows.toLocaleString()} of ${totalRows.toLocaleString()} rows`
                : progressStageLabels[stage] || 'Processing',
            autoClose: 0,
        };

        if (progress === null) {
            changes.indeterminate = true;
        } else {
            changes.progress = progress;
        }

        if (payload.status === 'completed') changes.type = 'success';
        if (payload.status === 'failed') changes.type = 'error';

        updateExportToast(state, changes);
    };

    const handleProgress = (payload = {}) => {
        const state = findActiveExport(payload.export_job_id);
        if (state) applyProgressUpdate(state, payload);
    };

    const recordsTotal = () => {
        if (typeof window.jQuery === 'undefined' || !window.jQuery.fn.dataTable) {
            return 'all';
        }

        const tables = window.jQuery.fn.dataTable.tables(true);
        if (!tables.length) {
            return 'all';
        }

        return window.jQuery(tables[0]).DataTable().page.info().recordsTotal;
    };

    const confirmExport = () => {
        const options = {
            title: 'Confirm Export',
            text: `You are about to export ${recordsTotal()} data rows to Excel. Continue?`,
            type: 'info',
            confirmTone: 'success',
            confirmText: 'Export',
            cancelText: 'Cancel',
        };

        if (window.AdasiAlert) {
            return window.AdasiAlert.confirm(options).then((result) => Boolean(result && result.isConfirmed));
        }

        return Promise.resolve(window.confirm(`${options.title}\n\n${options.text}`));
    };

    const requestUrlFor = (control) => {
        if (control instanceof HTMLFormElement) {
            const url = new URL(control.action, window.location.origin);
            const formData = new FormData(control);

            for (const [key, value] of formData.entries()) {
                if (typeof value === 'string') {
                    url.searchParams.set(key, value);
                }
            }

            return url.toString();
        }

        return new URL(control.href, window.location.origin).toString();
    };

    const busyElementFor = (control) => control instanceof HTMLFormElement
        ? control.querySelector('button[type="submit"], input[type="submit"]')
        : control;

    const setBusy = (control, busy) => {
        const element = busyElementFor(control);
        if (!element) {
            return;
        }

        if (busy) {
            if (element.dataset.asyncExportOriginalHtml === undefined && element instanceof HTMLButtonElement) {
                element.dataset.asyncExportOriginalHtml = element.innerHTML;
            }
            if (element.dataset.asyncExportOriginalText === undefined && element instanceof HTMLInputElement) {
                element.dataset.asyncExportOriginalText = element.value;
            }

            element.setAttribute('aria-disabled', 'true');
            element.classList.add('disabled');
            if ('disabled' in element) {
                element.disabled = true;
            }

            if (element instanceof HTMLButtonElement) {
                element.innerHTML = '<span class="spinner-border spinner-border-sm me-1" aria-hidden="true"></span> Menyiapkan...';
            } else if (element instanceof HTMLInputElement) {
                element.value = 'Menyiapkan...';
            }

            return;
        }

        element.removeAttribute('aria-disabled');
        element.classList.remove('disabled');
        if ('disabled' in element) {
            element.disabled = false;
        }

        if (element instanceof HTMLButtonElement && element.dataset.asyncExportOriginalHtml !== undefined) {
            element.innerHTML = element.dataset.asyncExportOriginalHtml;
            delete element.dataset.asyncExportOriginalHtml;
        } else if (element instanceof HTMLInputElement && element.dataset.asyncExportOriginalText !== undefined) {
            element.value = element.dataset.asyncExportOriginalText;
            delete element.dataset.asyncExportOriginalText;
        }
    };

    const responseError = async (response) => {
        let payload = null;

        try {
            payload = await response.json();
        } catch (error) {
            payload = null;
        }

        if (payload && payload.errors && typeof payload.errors === 'object') {
            const validationMessage = Object.values(payload.errors)
                .flat()
                .filter((message) => typeof message === 'string')
                .join('\n');

            if (validationMessage) {
                return validationMessage;
            }
        }

        if (payload && typeof payload.message === 'string' && payload.message.trim() !== '') {
            return payload.message;
        }

        return response.status === 401
            ? 'Your session has expired. Please sign in again.'
            : 'The export request could not be processed.';
    };

    const triggerDownload = async (downloadUrl, fileName, exportJobId) => {
        const response = await window.fetch(downloadUrl, {
            headers: {
                Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'X-Requested-With': 'XMLHttpRequest',
            },
            credentials: 'same-origin',
            cache: 'no-store',
        });

        if (!response.ok) {
            throw new Error(await responseError(response));
        }

        const contentType = (response.headers.get('Content-Type') || '').toLowerCase();
        if (contentType.includes('text/html')) {
            throw new Error('The download session is invalid. Please sign in again.');
        }

        const blob = await response.blob();
        if (!blob.size) {
            throw new Error('The export file is empty or unavailable.');
        }

        const objectUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.hidden = true;
        link.href = objectUrl;
        link.download = fileName || `export-${exportJobId}.xlsx`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => window.URL.revokeObjectURL(objectUrl), 60000);
    };

    const pollStatus = (state) => {
        let consecutiveFailures = 0;

        const finish = (retainNotificationSuppression = false) => {
            activeExports.delete(state.requestUrl);
            removePersistedExport(state.exportJobId);
            releaseTrackedExportJob(state.exportJobId, retainNotificationSuppression);
            setBusy(state.control, false);
        };

        const poll = async () => {
            if (Date.now() - state.startedAt >= pollTimeoutMs) {
                finish();
                updateExportToast(state, {
                    forceNotify: true,
                    type: 'warning',
                    title: 'Export is still processing',
                    message: 'Automatic monitoring has stopped. The file will remain available in Export History.',
                    autoClose: 0,
                });
                return;
            }

            try {
                const response = await window.fetch(state.statusUrl, {
                    headers: {
                        Accept: 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                    },
                    credentials: 'same-origin',
                    cache: 'no-store',
                });

                if (!response.ok) {
                    throw new Error(await responseError(response));
                }

                const payload = await response.json();
                consecutiveFailures = 0;
                applyProgressUpdate(state, payload);

                if (payload.status === 'completed') {
                    if (payload.download_url) {
                        const downloadJobId = payload.id || state.exportJobId;
                        if (!claimDownload(downloadJobId)) {
                            finish(true);
                            return;
                        }

                        try {
                            await triggerDownload(
                                payload.download_url,
                                payload.file_name,
                                downloadJobId
                            );
                            finish(true);
                            updateExportToast(state, {
                                forceNotify: true,
                                type: 'success',
                                title: 'Export completed',
                                message: 'The Excel file was downloaded automatically.',
                                progress: 100,
                                progressLabel: 'Completed',
                                autoClose: 4000,
                            });
                        } catch (error) {
                            releaseDownloadClaim(downloadJobId);
                            finish(true);
                            updateExportToast(state, {
                                forceNotify: true,
                                type: 'error',
                                title: 'Automatic download failed',
                                message: error instanceof Error ? error.message : 'Download the file from Export History.',
                                autoClose: 0,
                            });
                        }
                    } else {
                        finish(true);
                        updateExportToast(state, {
                            forceNotify: true,
                            type: 'error',
                            title: 'Export file is unavailable',
                            message: payload.message || 'The export file cannot be downloaded.',
                            autoClose: 0,
                        });
                    }
                    return;
                }

                if (payload.status === 'failed') {
                    finish(true);
                    updateExportToast(state, {
                        forceNotify: true,
                        type: 'error',
                        title: 'Export could not be completed',
                        message: payload.message || 'Try the export again or review Export History.',
                        autoClose: 0,
                    });
                    return;
                }

                if (payload.status !== 'queued' && payload.status !== 'processing') {
                    finish();
                    updateExportToast(state, {
                        forceNotify: true,
                        type: 'error',
                        title: 'Export status is unavailable',
                        message: 'Review the job in Export History.',
                        autoClose: 0,
                    });
                    return;
                }

            } catch (error) {
                consecutiveFailures += 1;

                if (consecutiveFailures >= maxConsecutivePollFailures) {
                    finish();
                    updateExportToast(state, {
                        forceNotify: true,
                        type: 'warning',
                        title: 'Export status could not be refreshed',
                        message: 'The file will remain available in Export History after processing.',
                        autoClose: 0,
                    });
                    return;
                }
            }

            window.setTimeout(poll, pollIntervalMs);
        };

        window.setTimeout(poll, pollIntervalMs);
    };

    const startExport = async (control) => {
        const requestUrl = requestUrlFor(control);
        if (activeExports.has(requestUrl)) {
            return;
        }

        const state = {
            control,
            requestUrl,
            exportJobId: null,
            statusUrl: null,
            toastId: createStartingToast(),
            silent: false,
            lastStatus: 'starting',
            lastStage: 'starting',
            lastProgressSignature: null,
            startedAt: Date.now(),
        };

        activeExports.set(requestUrl, state);
        setBusy(control, true);

        try {
            const response = await window.fetch(requestUrl, {
                headers: {
                    Accept: 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                credentials: 'same-origin',
                cache: 'no-store',
            });

            if (!response.ok) {
                throw new Error(await responseError(response));
            }

            const payload = await response.json();
            if (!payload.export_job_id || !payload.status_url) {
                throw new Error('The export response is incomplete.');
            }

            state.exportJobId = payload.export_job_id;
            state.statusUrl = payload.status_url;
            state.lastStatus = 'queued';
            trackExportJob(state.exportJobId);
            persistPendingExport(state);

            if (state.toastId) {
                applyProgressUpdate(state, {
                    status: 'queued',
                    stage: 'queued',
                    progress: 0,
                    processed_rows: 0,
                    total_rows: 0,
                    message: payload.message || 'The export will continue in the background.',
                });
                updateExportToast(state, { actions: exportActions(payload.exports_url) });
            } else {
                notify('info', 'Export queued', payload.message || 'The file will download automatically when ready.');
            }

            pollStatus(state);
        } catch (error) {
            activeExports.delete(requestUrl);
            releaseTrackedExportJob(state.exportJobId);
            setBusy(control, false);
            updateExportToast(state, {
                type: 'error',
                title: 'Unable to Start Export',
                message: error instanceof Error ? error.message : 'The export request could not be processed.',
                autoClose: 0,
            });
        }
    };

    const resumePersistedExports = () => {
        readPendingExports().forEach((record) => {
            const exportJobId = normalizeExportJobId(record.exportJobId);
            const requestUrl = `__persisted_export__:${exportJobId}`;

            if (!exportJobId || findActiveExport(exportJobId) || activeExports.has(requestUrl)) {
                return;
            }

            const state = {
                control: null,
                requestUrl,
                exportJobId,
                statusUrl: record.statusUrl,
                toastId: null,
                silent: true,
                rehydrateToast: true,
                lastStatus: 'queued',
                lastStage: 'queued',
                lastProgress: null,
                lastProcessedRows: 0,
                lastTotalRows: 0,
                lastMessage: '',
                lastProgressSignature: null,
                startedAt: Number(record.startedAt) || Date.now(),
            };

            activeExports.set(requestUrl, state);
            trackExportJob(exportJobId);
            applyProgressUpdate(state, {
                status: record.status || 'queued',
                stage: record.stage || 'queued',
                progress: record.progress,
                processed_rows: record.processedRows || 0,
                total_rows: record.totalRows || 0,
                message: record.message || 'The export is continuing in the background.',
            });
            pollStatus(state);
        });
    };

    window.AdasiAsyncExport = Object.freeze({
        handleProgress,
        isTrackingNotification,
    });

    resumePersistedExports();

    const confirmAndStart = async (control) => {
        if (confirmationOpen) {
            return;
        }

        confirmationOpen = true;

        try {
            if (await confirmExport()) {
                await startExport(control);
            }
        } finally {
            confirmationOpen = false;
        }
    };

    document.addEventListener('click', (event) => {
        const target = event.target instanceof Element ? event.target : null;
        const link = target?.closest('a[href]');
        if (!link || !isAsyncExportControl(link) || event.button !== 0) {
            return;
        }

        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
            return;
        }

        event.preventDefault();
        confirmAndStart(link);
    }, true);

    document.addEventListener('submit', (event) => {
        const form = event.target;
        if (!(form instanceof HTMLFormElement) || !isAsyncExportControl(form)) {
            return;
        }

        event.preventDefault();
        event.stopImmediatePropagation();
        confirmAndStart(form);
    }, true);
})(window, document);
